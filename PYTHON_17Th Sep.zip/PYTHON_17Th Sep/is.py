x = [10,20,30]
y = [10,20,30]
z = [10,20,30]
if x is z:
  print("true")
if y is z:
   print("false")
      
else:
    print("false")
print("hello")
 
