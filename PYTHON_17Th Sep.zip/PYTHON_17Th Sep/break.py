for letter in " abhi":
   if letter =='b':
       break
   else:
        print(letter)
     
print("thankyou")
     
