List 1 = [0,9,8,7]
List 2 =[3,4,5,6]
List 3 = [0.4,9,0,5.6]
List 1.insert(0)
print(List1)
List append()
print(List2)
List 3. reverse()
print(List3)
print(List1)
print(List2)
print(List3)
